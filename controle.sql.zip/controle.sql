-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Set 13, 2017 as 10:38 PM
-- Versão do Servidor: 5.0.67
-- Versão do PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `controle`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `ajuste`
--

CREATE TABLE IF NOT EXISTS `ajuste` (
  `id` int(11) NOT NULL auto_increment,
  `data` date NOT NULL,
  `produto` int(11) NOT NULL,
  `qtde_entrada` int(11) NOT NULL,
  `qtde_saida` int(11) NOT NULL,
  `obs` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `ajuste`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `destinos`
--

CREATE TABLE IF NOT EXISTS `destinos` (
  `CODDEST` int(11) NOT NULL auto_increment,
  `DESCRICAO` varchar(30) default NULL,
  PRIMARY KEY  (`CODDEST`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Extraindo dados da tabela `destinos`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `entra`
--

CREATE TABLE IF NOT EXISTS `entra` (
  `CONTROLE` int(11) NOT NULL auto_increment,
  `NFNR` varchar(10) default NULL,
  `DATA` date default NULL,
  `VALORNF` double default NULL,
  `FORNECEDOR` int(11) default NULL,
  PRIMARY KEY  (`CONTROLE`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `entra`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `fornec`
--

CREATE TABLE IF NOT EXISTS `fornec` (
  `CODIGO` int(11) NOT NULL auto_increment,
  `NOME` varchar(45) default NULL,
  `CONTATO` varchar(30) default NULL,
  `CGC` varchar(14) default NULL,
  `IE` varchar(15) default NULL,
  `RUA` varchar(45) default NULL,
  `BAIRRO` varchar(20) default NULL,
  `CIDADE` varchar(25) default NULL,
  `UF` char(2) default NULL,
  `CEP` varchar(8) default NULL,
  `FONENOVO` varchar(11) default NULL,
  `FONE_2` varchar(10) default NULL,
  `FONE_3` varchar(10) default NULL,
  `FAX` varchar(10) default NULL,
  `INTREF` double default NULL,
  PRIMARY KEY  (`CODIGO`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=431 ;

--
-- Extraindo dados da tabela `fornec`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `grupos`
--

CREATE TABLE IF NOT EXISTS `grupos` (
  `CODGRUP` int(11) NOT NULL auto_increment,
  `GRUPO` varchar(25) default NULL,
  PRIMARY KEY  (`CODGRUP`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Extraindo dados da tabela `grupos`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `itensent`
--

CREATE TABLE IF NOT EXISTS `itensent` (
  `CONTROLE` int(11) default NULL,
  `NRITEM` int(11) default NULL,
  `PRODUTO` int(11) default NULL,
  `QUANT` double default NULL,
  `CUSTO` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `itensent`
--

INSERT INTO `itensent` (`CONTROLE`, `NRITEM`, `PRODUTO`, `QUANT`, `CUSTO`) VALUES
(1, 1, 1162, 0, 0),
(2, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE IF NOT EXISTS `produtos` (
  `CODPROD` int(11) NOT NULL auto_increment,
  `PRODUTO` varchar(40) default NULL,
  `UNIDADE` char(2) default NULL,
  `GRUPO` int(11) default NULL,
  `CUSTO` double default NULL,
  `CUSTOMED` double default NULL,
  `EMBALAGEM` double default NULL,
  `ESTOQUE` double default NULL,
  `MINIMO` double default NULL,
  `VENCTO` datetime default NULL,
  PRIMARY KEY  (`CODPROD`),
  KEY `CUSTO` (`CUSTO`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2249 ;

--
-- Extraindo dados da tabela `produtos`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `saidas`
--

CREATE TABLE IF NOT EXISTS `saidas` (
  `CONTRSAI` int(11) NOT NULL auto_increment,
  `DOCUMENTO` varchar(12) default NULL,
  `DESTINO` int(11) default NULL,
  `NOMEDEST` varchar(30) default NULL,
  `DATA` date default NULL,
  `RESPONSAV` varchar(30) default NULL,
  `OBS` text NOT NULL,
  `ENTREGAR` int(1) NOT NULL default '1',
  PRIMARY KEY  (`CONTRSAI`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `saidas`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `sitens`
--

CREATE TABLE IF NOT EXISTS `sitens` (
  `CONTRSAI` int(11) default NULL,
  `NRIT` int(11) default NULL,
  `PRODUTO` int(11) default NULL,
  `QUANT` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `sitens`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `syslogin`
--

CREATE TABLE IF NOT EXISTS `syslogin` (
  `id` tinyint(4) NOT NULL auto_increment,
  `nome` varchar(32) NOT NULL,
  `usuario` varchar(32) NOT NULL,
  `senha` varchar(32) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `syslogin`
--

INSERT INTO `syslogin` (`id`, `nome`, `usuario`, `senha`) VALUES
(1, 'teste', 'teste', '698dc19d489c4e4db73e28a713eab07b'),
(2, 'Administrador', 'dse', 'e73a23a8382b8f6b9e24a3aa9a39afa2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `unidades`
--

CREATE TABLE IF NOT EXISTS `unidades` (
  `CODUNI` char(2) NOT NULL default '',
  `UNIDADE` varchar(10) default NULL,
  PRIMARY KEY  (`CODUNI`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `unidades`
--

